import React from 'react';
import { Calendar, Clock, BookOpen, AlertCircle, User, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { getAuth, signOut } from 'firebase/auth';

const HomePage = () => {
    const navigate = useNavigate();
    const auth = getAuth();

    // Sample data
    const upcomingLessons = [
        { student: "Adam", subject: "Math", time: "3:00 PM", duration: "1 hour" },
        { student: "Sara", subject: "English", time: "4:30 PM", duration: "1 hour" },
        { student: "Mohammad", subject: "Science", time: "6:00 PM", duration: "1.5 hours" }
    ];

    const importantNotes = [
        "Adam's algebra exam is this Thursday",
        "Sara needs extra focus on reading comprehension",
        "Review this week's homework with Mohammad"
    ];

    const handleSignOut = async () => {
        try {
            await signOut(auth);
            navigate('/login');
        } catch (error) {
            console.error('Error signing out:', error);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Header */}
            <header className="bg-white shadow">
                <div className="max-w-7xl mx-auto py-4 px-4">
                    <div className="flex justify-between items-center">
                        <h1 className="text-2xl font-bold text-gray-900">Welcome to TarkizPlus</h1>
                        <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2">
                                <User className="h-5 w-5" />
                                <span>Teacher Dashboard</span>
                            </div>
                            <button
                                onClick={handleSignOut}
                                className="flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-md transition-colors"
                            >
                                <LogOut className="h-4 w-4" />
                                Sign Out
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <main className="max-w-7xl mx-auto py-6 px-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Today's Schedule */}
                    <div className="bg-white p-6 rounded-lg shadow">
                        <div className="flex items-center gap-2 mb-4">
                            <Calendar className="h-5 w-5 text-blue-500" />
                            <h2 className="text-xl font-semibold">Today's Schedule</h2>
                        </div>
                        <div className="space-y-4">
                            {upcomingLessons.map((lesson, index) => (
                                <div key={index} className="flex items-start gap-4 p-3 bg-gray-50 rounded">
                                    <Clock className="h-5 w-5 text-gray-500 mt-1" />
                                    <div>
                                        <p className="font-medium">{lesson.time} - {lesson.student}</p>
                                        <p className="text-sm text-gray-600">
                                            {lesson.subject} ({lesson.duration})
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Important Notes */}
                    <div className="bg-white p-6 rounded-lg shadow">
                        <div className="flex items-center gap-2 mb-4">
                            <AlertCircle className="h-5 w-5 text-red-500" />
                            <h2 className="text-xl font-semibold">Important Notes</h2>
                        </div>
                        <div className="space-y-3">
                            {importantNotes.map((note, index) => (
                                <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded">
                                    <BookOpen className="h-5 w-5 text-gray-500 mt-1" />
                                    <p>{note}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default HomePage;